package maintenance

// Start starts the maintenance process.
func Start() {
	CheckForUpdates()
}
