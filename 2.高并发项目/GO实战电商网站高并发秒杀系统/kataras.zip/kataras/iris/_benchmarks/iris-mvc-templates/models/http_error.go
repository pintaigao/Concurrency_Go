package models

// HTTPError a silly structure to keep our error page data.
type HTTPError struct {
	Title string
	Code  int
}
