# Typescript

[Typescript](http://www.typescriptlang.org/) and [alm-tools cloud editor](http://alm.tools/) automation tools for the [iris](https://github.com/kataras/iris) web framework.


## Table of contents

* [Typescript compiler](_examples/typescript/main.go)
* [Alm-tools cloud editor](_examples/editor/main.go)