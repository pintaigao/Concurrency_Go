A silly example for this issue: https://github.com/kataras/iris/issues/688#issuecomment-318828259.
However it seems useful and therefore is being included in the examples for everyone else.